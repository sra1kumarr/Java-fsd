/**
 * 
 */
/**
 * 
 */
module BinarySearch {
}