/**
 * 
 */
/**
 * 
 */
module Camerarental {
}