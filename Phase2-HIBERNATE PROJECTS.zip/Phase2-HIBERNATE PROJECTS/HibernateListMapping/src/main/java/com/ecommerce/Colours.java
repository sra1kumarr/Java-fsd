package com.ecommerce;




public class Colours {
        private long COLORID;
        private String name;
        
        public Colours() {
                
        }
        public Colours(String name) {
                this.COLORID = 0;
                this.name = name;
        }
        
        public long getCOLOURSID() {return this.COLORID; }
        public String getName() { return this.name;}
        public void setCOLOURSID(long id) { this.COLORID = id;}
        public void setName(String name) { this.name = name;}
        
        
}
