package com.constructors;
class Constructor_Demo{
	int id;
	String name;

void display() {
	System.out.println(id+" "+name);
	}
}

public class ConstructorDemo {

public static void main(String[] args) {

	Constructor_Demo emp1=new Constructor_Demo();
	Constructor_Demo emp2=new Constructor_Demo();

	emp1.display();
	emp2.display();
	}
}

//parameterized constructor
