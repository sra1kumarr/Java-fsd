/**
 * 
 */
/**
 * 
 */
module typeCasting {
}