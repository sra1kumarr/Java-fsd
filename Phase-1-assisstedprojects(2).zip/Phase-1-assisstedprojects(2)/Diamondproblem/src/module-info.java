/**
 * 
 */
/**
 * 
 */
module Diamondproblem {
}